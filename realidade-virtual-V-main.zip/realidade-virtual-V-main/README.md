Atividade de Edição de Visual Estudio code. Pegar e fazer seu proprio cenario e personagens e salvar em versões no github. 
Atualmente o código é direto do "Simpósio VR" De Classroom. Devera ser feitos alterações no código com Objetivo: **De entender o Código**

*Data de Entrega: 29/08*

*Devera escolher as seguinte coisas:*
- Cenario (360) Sala de Aula (Alexia Escolheu)
- Personagens ???
